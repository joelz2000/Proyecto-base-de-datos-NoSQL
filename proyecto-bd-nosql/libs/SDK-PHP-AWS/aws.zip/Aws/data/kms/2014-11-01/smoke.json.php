<?php
// This file was auto-generated from sdk-root/src/data/kms/2014-11-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListAliases', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetKeyPolicy', 'input' => [ 'KeyId' => '12345678-1234-1234-1234-123456789012', 'PolicyName' => 'fakePolicy', ], 'errorExpectedFromService' => true, ], ],];
