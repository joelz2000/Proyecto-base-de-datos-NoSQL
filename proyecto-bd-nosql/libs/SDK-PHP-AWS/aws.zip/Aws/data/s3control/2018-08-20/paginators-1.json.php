<?php
// This file was auto-generated from sdk-root/src/data/s3control/2018-08-20/paginators-1.json
return [ 'pagination' => [],];
