<?php
// This file was auto-generated from sdk-root/src/data/elasticmapreduce/2009-03-31/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListClusters', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeCluster', 'input' => [ 'ClusterId' => 'fake_cluster', ], 'errorExpectedFromService' => true, ], ],];
