<?php
// This file was auto-generated from sdk-root/src/data/config/2014-11-12/paginators-1.json
return [ 'pagination' => [ 'GetResourceConfigHistory' => [ 'input_token' => 'nextToken', 'limit_key' => 'limit', 'output_token' => 'nextToken', 'result_key' => 'configurationItems', ], ],];
